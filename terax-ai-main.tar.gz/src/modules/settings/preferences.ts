import { create } from "zustand";
import {
  DEFAULT_PREFERENCES,
  loadPreferences,
  onPreferencesChange,
  type Preferences,
} from "./store";

type State = Preferences & {
  hydrated: boolean;
  /** Subscribe & hydrate. Idempotent — safe to call from multiple windows. */
  init: () => Promise<void>;
};

let initPromise: Promise<void> | null = null;

const FAST_BG_KIND_KEY = "terax-ui-bg-kind-shadow";
const FAST_BG_IMAGE_ID_KEY = "terax-ui-bg-image-shadow";
const FAST_BG_IMAGE_URL_KEY = "terax-ui-bg-url-shadow";

function mirrorBgFastPath(
  kind: Preferences["backgroundKind"],
  imageId: Preferences["backgroundImageId"],
  imageUrl: Preferences["backgroundImageUrl"],
): void {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(FAST_BG_KIND_KEY, kind);
    if (imageId) window.localStorage.setItem(FAST_BG_IMAGE_ID_KEY, imageId);
    else window.localStorage.removeItem(FAST_BG_IMAGE_ID_KEY);
    if (imageUrl) window.localStorage.setItem(FAST_BG_IMAGE_URL_KEY, imageUrl);
    else window.localStorage.removeItem(FAST_BG_IMAGE_URL_KEY);
  } catch {
    /* ignore */
  }
}

export function readBgFastPath(): {
  active: boolean;
  imageId: string | null;
  url: string | null;
} {
  if (typeof window === "undefined") return { active: false, imageId: null, url: null };
  try {
    const kind = window.localStorage.getItem(FAST_BG_KIND_KEY);
    const imageId = window.localStorage.getItem(FAST_BG_IMAGE_ID_KEY);
    const url = window.localStorage.getItem(FAST_BG_IMAGE_URL_KEY);
    return {
      active: (kind === "image" && !!imageId) || (kind === "url" && !!url),
      imageId,
      url,
    };
  } catch {
    return { active: false, imageId: null, url: null };
  }
}

export const usePreferencesStore = create<State>((set) => ({
  ...DEFAULT_PREFERENCES,
  hydrated: false,
  init: () => {
    if (initPromise) return initPromise;
    initPromise = (async () => {
      try {
        const prefs = await loadPreferences();
        set({ ...prefs, hydrated: true });
        mirrorBgFastPath(prefs.backgroundKind, prefs.backgroundImageId, prefs.backgroundImageUrl);
        void onPreferencesChange((key, value) => {
          set({ [key]: value } as Partial<State>);
          if (key === "backgroundKind" || key === "backgroundImageId" || key === "backgroundImageUrl") {
            const s = usePreferencesStore.getState();
            mirrorBgFastPath(s.backgroundKind, s.backgroundImageId, s.backgroundImageUrl);
          }
        });
      } catch (e) {
        initPromise = null;
        throw e;
      }
    })();
    return initPromise;
  },
}));
